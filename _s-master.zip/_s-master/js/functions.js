(function($){
    $('figure.wp-caption.alignment').removeAttr('style');
    $('img.aligncenter').wrap('<figure class="centered-image" />');
})(jQuery);

